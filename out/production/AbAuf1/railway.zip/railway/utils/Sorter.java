package railway.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public final class Sorter {
    public static String sortList(String list, SortAlgorithm algorithm) {
        String temp[] = list.split("\n");
        ArrayList<String> lines = new ArrayList<String>(Arrays.asList(temp));
        Collections.sort(lines, algorithm);
        String str = "";
        for (String s : lines) {
            str += s + "\n";
        }
        return str.trim();
    }
}
