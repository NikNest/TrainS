package railway.utils;

public final class TrainOnRoad {
    private Train train;
    private Track trackHead;
    //direction of moving forward
    private boolean isStartDirection;
    private Point positionHead;
    private boolean crashed = false;
    private boolean movingBack = false;

    public TrainOnRoad(Train train, Track track, boolean isStartDirection, Point currentPosition) {
        this.train = train;
        this.trackHead = track;
        this.isStartDirection = isStartDirection;
        this.positionHead = currentPosition;

    }

    public void setMovingBack(boolean movingBack) {
        this.movingBack = movingBack;
    }

    public void setStartDirection(boolean isStartDirection) {
        this.isStartDirection = isStartDirection;
    }

    public void setCrashed(boolean crashed) {
        this.crashed = crashed;
    }

    public boolean isMovingBack() {
        return movingBack;
    }

    public boolean isCrashed() {
        return crashed;
    }

    public Train getTrain() {
        return train;
    }

    public int getLength() {
        return train.getTrainLength();
    }

    public Track getTrackHead() {
        return trackHead;
    }

    public boolean isStartDirection() {
        return isStartDirection;
    }

    public Point getPositionHead() {
        return positionHead;
    }

    @Override
    public String toString() {
        return "Train " + train.getTrainId() + " at " + positionHead;
    }
}
