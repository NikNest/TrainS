package railway.utils;

public final class TrainSet extends TrainPart implements SpecialIdable {
    private final String trainsetClass;
    private final String trainsetName;

    public TrainSet(String trainsetClass, String trainsetName,
                    int length, boolean forwConnected, boolean backConnected) {
        this.trainsetClass = trainsetClass;
        this.trainsetName = trainsetName;
        this.setLength(length);
        this.setForwConnection(forwConnected);
        this.setBackConnection(backConnected);
    }

    @Override
    public String getSpecialClass() {
        return trainsetClass;
    }

    @Override
    public String getSpecialName() {
        return trainsetName;
    }

    @Override
    public String toString() {
        String str = "";
        if (getTrainId() != 0) str += getTrainId() + " ";
        else str += "none ";
        str += trainsetClass + " " + trainsetName + " " + getLength() + " "
            + isForwConnection() + " " + isBackConnection();
        return str;
    }
}
