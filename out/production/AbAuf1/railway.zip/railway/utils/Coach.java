package railway.utils;

/**
 * class for coach and logic of this trainpart
 * @author Nikita
 * @version 1
 */
public final class Coach extends TrainPart {
    private final String type;
    private final int id;

    public Coach(String coachType, int length, boolean forwConnected, boolean backConnected, int id) {
        this.type = coachType;
        this.setLength(length);
        this.setForwConnection(forwConnected);
        this.setBackConnection(backConnected);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        String str = "";
        str += id + " ";
        if (getTrainId() != 0) str += getTrainId() + " ";
        else str += "none ";
        if (type.equals("passenger"))
            str += "p";
        else if (type.equals("freight"))
            str += "f";
        else
            str += "s";
        str += " " + getLength() + " " + isForwConnection() + " " + isBackConnection();
        return str;
    }
}
