package railway.utils;

import edu.kit.informatik.Terminal;

/**
 *
 */
public final class IncorrectInputException extends Exception {
    public IncorrectInputException() {
        Terminal.printError("Incorrect input");
    }

    public IncorrectInputException(String string) {
        Terminal.printError(string);
    }
}
