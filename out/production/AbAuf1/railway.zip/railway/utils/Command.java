package railway.utils;

/**
 * class for storing the value of command and the command itself in an appropriate form
 * @author Nikita
 * @version 1
 */
public final class Command {
    private final String[] value;
    private final String command;

    public Command(String[] value, String command) {
        this.value = value;
        this.command = command;
    }

    public String[] getValue() {
        return value;
    }

    public String getCommand() {
        return command;
    }
}
